import { Router } from 'express';
import productRoutes from './productRoutes.js';
import customerRoutes from './customerRoutes.js';
import orderRoutes from './orderRoutes.js';
import harvestLocationRoutes from './harvestLocationRoutes.js';
import invoiceRoutes from './invoiceRoutes.js';
import reportRoutes from './reportRoutes.js';

const router = Router();

// API routes
router.use('/products', productRoutes);
router.use('/customers', customerRoutes);
router.use('/orders', orderRoutes);
router.use('/harvest-locations', harvestLocationRoutes);
router.use('/invoices', invoiceRoutes);
router.use('/reports', reportRoutes);

// Health check
router.get('/health', (_req, res) => {
    res.json({ success: true, message: 'API is running', timestamp: new Date().toISOString() });
});

export default router;
